# Cat Grid Solver (Android project)

An offline Android WebView app that lets a user select a screenshot, mark the centres of the top-left and bottom-right grid cells, enter board dimensions, and run a constraint solver. The solver assumes a square board and one cat per connected colour region, one per row/column, and no touching even diagonally.

## Build an APK
1. Open this folder in Android Studio (Giraffe or newer).
2. Allow Gradle to sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio outputs the APK under `app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have Android SDK/Gradle installed, so an APK binary could not be compiled here. The project source is provided so it can be built in Android Studio.
